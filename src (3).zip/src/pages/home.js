import React, { useState, useEffect } from "react";

import Login from "./login";
import Register from "./register";
import logo from "../asserts/logo.png";       // Logo imported correctly
import heroImage from "../asserts/logo.png"; // Optional hero image
import "../App.css";
import "./home.css";

export default function Home() {
  const [activeForm, setActiveForm] = useState(null); // null | "login" | "register"
   useEffect(() => {
    document.body.classList.add("no-scroll");
    return () => document.body.classList.remove("no-scroll");
  }, []);

  return (
    <div className="home-container">
      {/* HEADER */}
      <header className="header">
        <div className="header-left">
          <img src={logo} alt="NeuroFleetX Logo" className="small-logo" />
          <span className="site-name">NeuroFleetX</span>
        </div>

        <nav className="header-center">
          <button className="nav-btn">Home</button>
          <button className="nav-btn">About</button>
          <button className="nav-btn">Contact</button>
        </nav>

        <div className="header-right">
          {!activeForm && (
            <button className="auth-btn" onClick={() => setActiveForm("login")}>
              Login
            </button>
          )}
        </div>
      </header>

      {/* MAIN HERO SECTION */}
      <main className="main-section">
        {!activeForm && (
          <div className="welcome-section">
            <img src={heroImage} alt="Fleet illustration" className="hero-img" />
            <h1>Welcome to NeuroFleetX</h1>
            <p>AI-Based Urban Fleet & Traffic Management</p>
            <div className="hero-buttons">
              <button
                className="home-btn"
                onClick={() => setActiveForm("login")}
              >
                Login
              </button>
              <button
                className="home-btn-outline"
                onClick={() => setActiveForm("register")}
              >
                Create Account
              </button>
            </div>
          </div>
        )}

        {activeForm === "login" && <Login switchPage={setActiveForm} />}
        {activeForm === "register" && <Register switchPage={setActiveForm} />}
      </main>

      {/* FOOTER */}
      <footer className="footer">
        © 2025 NeuroFleetX. All Rights Reserved.
      </footer>
    </div>
  );
}
