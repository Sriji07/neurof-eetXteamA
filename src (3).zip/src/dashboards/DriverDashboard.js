import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import MetricCard from "../components/MetricCard";
import "../dashboards/dashboard.css";

export default function DriverDashboard() {
  return (
    <DashboardLayout title="Driver Dashboard">
         <h2 className="dashboard-welcome">Welcome to Driver Dashboard</h2>
      <div className="dashboard-main">
        <div className="metrics-grid">
          <MetricCard title="Today's Trips" value="6" />
          <MetricCard title="Today's Earnings" value="₹ 1,450" />
          <MetricCard title="Distance Covered" value="74 km" />
          <MetricCard title="Driver Rating" value="4.7 ★" />
          <MetricCard title="Completed Trips" value="1,423" />
          <MetricCard title="Acceptance Rate" value="96%" />
        </div>
      </div>
    </DashboardLayout>
  );
}
