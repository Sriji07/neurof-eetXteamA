import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import MetricCard from "../components/MetricCard";
import "../dashboards/dashboard.css";

export default function CustomerDashboard() {
  return (
    <DashboardLayout title="Customer Dashboard">
      <div className="dashboard-main">
        <h2 className="dashboard-welcome">Welcome to Customer Dashboard</h2>

        <div className="metrics-grid">
          <MetricCard title="Active Bookings" value="2" />
          <MetricCard title="Total Trips" value="87" />
          <MetricCard title="Total Spent" value="₹ 18,540" />
          <MetricCard title="Amount Saved" value="₹ 1,260" />
          <MetricCard title="Upcoming Trips" value="3" />
          <MetricCard title="Favorite Routes" value="6" />
        </div>
      </div>
    </DashboardLayout>
  );
}
