import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

/* Pages */
import Home from "./pages/home";
import Login from "./pages/login";
import Register from "./pages/register";
import Unauthorized from "./pages/Unauthorized";
import Profile from "./pages/profile"; // lowercase to match filename

/* Dashboards */
import AdminDashboard from "./dashboards/AdminDashboard";
import FleetManagerDashboard from "./dashboards/FleetManagerDashboard";
import DriverDashboard from "./dashboards/DriverDashboard";
import CustomerDashboard from "./dashboards/CustomerDashboard";

/* Components */
import ProtectedRoute from "./components/ProtectedRoute";
import Navbar from "./components/Navbar";
import ProfileSidebar from "./components/ProfileSidebar";

/* Utils */
import { getUser } from "./utils/authUtils";

// Redirect to role-based dashboard
const DashboardRedirect = () => {
  const user = getUser();
  if (!user) return <Navigate to="/login" replace />;

  const role = user?.role?.toLowerCase();
  const roleMap = {
    admin: "/admin",
    "fleet manager": "/fleet",
    fleet_manager: "/fleet",
    fleet: "/fleet",
    driver: "/driver",
    customer: "/customer",
    user: "/customer",
  };

  return <Navigate to={roleMap[role] || "/unauthorized"} replace />;
};

export default function App() {
  const user = getUser();

  return (
    <Router>
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        {/* Navbar visible only after leaving Home page */}
        {user && window.location.pathname !== "/" && <Navbar />}

        <main style={{ display: "flex", flex: 1 }}>
          {/* Sidebar for logged-in users */}
          {user && window.location.pathname !== "/" && <ProfileSidebar />}

          <div
            style={{
              flex: 1,
              marginLeft: user && window.location.pathname !== "/" ? "60px" : "0",
              padding: user && window.location.pathname !== "/" ? "80px 20px 20px 20px" : "0",
            }}
          >
            <Routes>
              {/* Home page */}
              <Route path="/" element={<Home />} />

              {/* Public pages */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/unauthorized" element={<Unauthorized />} />

              {/* Full-page profile */}
              <Route path="/profile" element={<Profile />} />

              {/* Dashboard redirect */}
              <Route path="/dashboard" element={<DashboardRedirect />} />

              {/* Protected Dashboards */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute allowedRoles={["Admin", "admin"]}>
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/fleet"
                element={
                  <ProtectedRoute allowedRoles={["Fleet Manager", "fleet_manager", "fleet"]}>
                    <FleetManagerDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/driver"
                element={
                  <ProtectedRoute allowedRoles={["Driver", "driver"]}>
                    <DriverDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/customer"
                element={
                  <ProtectedRoute allowedRoles={["Customer", "customer", "user"]}>
                    <CustomerDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Catch-all */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  );
}
