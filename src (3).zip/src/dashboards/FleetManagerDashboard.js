import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import MetricCard from "../components/MetricCard";
import "../dashboards/dashboard.css";

export default function FleetManagerDashboard() {
  return (
    <DashboardLayout title="Fleet Manager Dashboard">
      <div className="dashboard-main">
        <h2 className="dashboard-welcome">Welcome to Fleet Manager Dashboard</h2>

        <div className="metrics-grid">
          <MetricCard title="Active Vehicles" value="120" />
          <MetricCard title="Trips Today" value="480" />
          <MetricCard title="Vehicle Health Alerts" value="7" />
          <MetricCard title="Idle Vehicles" value="15" />
          <MetricCard title="Fuel Efficiency" value="89%" />
          <MetricCard title="Traffic Alerts" value="5" />
        </div>
      </div>
    </DashboardLayout>
  );
}
