import React from "react";
import { useNavigate } from "react-router-dom";
import { getUser, logout } from "../utils/authUtils";

export default function Navbar() {
  const navigate = useNavigate();
  const user = getUser();

  return (
    <nav style={styles.navbar}>
      <div style={styles.left}>
        <h2 style={{ color: "white" }}>NeuroFleetX</h2>
      </div>

      <div style={styles.right}>
        <span style={styles.userInfo}>
          {user?.name} ({user?.role})
        </span>

        <button style={styles.profileBtn} onClick={() => navigate("/profile")}>
          Profile
        </button>

        <button
          style={styles.logoutBtn}
          onClick={() => {
            logout();
            navigate("/login");
          }}
        >
          Logout
        </button>
      </div>
    </nav>
  );
}

const styles = {
  navbar: {
    width: "100%",
    background: "#0d1b3d",
    padding: "15px 40px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    color: "white"
  },
  left: {
    fontSize: "22px",
    fontWeight: "bold"
  },
  right: {
    display: "flex",
    gap: "20px",
    alignItems: "center"
  },
  userInfo: {
    fontWeight: "bold"
  },
  profileBtn: {
    padding: "8px 16px",
    background: "#2287e5",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  },
  logoutBtn: {
    padding: "8px 16px",
    background: "red",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  }
};
