import React, { useState } from "react";
import bg from "../asserts/img5.png";
import { useNavigate } from "react-router-dom";

export default function Register() {
  const navigate = useNavigate();
  const [role, setRole] = useState("");
  const [gender, setGender] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPass, setConfirmPass] = useState("");

  const handleRegister = () => {
    if (!role || !gender || !mobile || !email || !password || !confirmPass) {
      alert("Please fill all details");
      return;
    }

    if (mobile.length !== 10) {
      alert("Mobile number must be exactly 10 digits");
      return;
    }

    if (password !== confirmPass) {
      alert("Passwords do not match");
      return;
    }

    const user = { role, gender, mobile, email, password };
    localStorage.setItem("userData", JSON.stringify(user));
    alert("Registration Successful!");
    navigate("/login");
  };

  return (
    <div
      style={{
        minHeight: "80vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backdropFilter: "blur(2px)",
      }}
    >
      <div
        style={{
          width: "450px",
          padding: "35px",
          borderRadius: "25px",
          background: "rgba(255,255,255,0.95)",
          boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
          color:"black"
        }}
      >
        <h1 style={{ textAlign: "center", color: "#2287e5e5", marginBottom: "5px" }}>NeuroFleetX</h1>
        <h2 style={{ textAlign: "center", marginTop: "0px", marginBottom: "15px" }}>Register Here</h2>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
          <label>Role</label>
          <select value={role} onChange={(e) => setRole(e.target.value)} style={{ width: "100%", padding: "10px", marginTop: "5px" }}>
            <option value="">-- Select Role --</option>
            <option value="Admin">Admin</option>
            <option value="Fleet Manager">Fleet Manager</option>
            <option value="Driver">Driver</option>
            <option value="Customer">Customer</option>
          </select>

          <label style={{ marginTop: "15px" }}>Gender</label>
          <div style={{ display: "flex", gap: "20px", marginTop: "5px" }}>
            <label><input type="radio" checked={gender==="Male"} onChange={()=>setGender("Male")}/> Male</label>
            <label><input type="radio" checked={gender==="Female"} onChange={()=>setGender("Female")}/> Female</label>
            <label><input type="radio" checked={gender==="Other"} onChange={()=>setGender("Other")}/> Other</label>
          </div>

          <label style={{ marginTop: "15px" }}>Mobile Number</label>
          <input type="text" value={mobile} onChange={(e)=>{const val=e.target.value; if(/^\d{0,10}$/.test(val)) setMobile(val);}} placeholder="Enter Mobile Number" style={{ width: "100%", padding: "10px" }} />

          <label style={{ marginTop: "15px" }}>Email</label>
          <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="Enter Email" style={{ width: "100%", padding: "10px" }} />

          <label style={{ marginTop: "15px" }}>Password</label>
          <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Enter Password" style={{ width: "100%", padding: "10px" }} />

          <label style={{ marginTop: "15px" }}>Confirm Password</label>
          <input type="password" value={confirmPass} onChange={(e)=>setConfirmPass(e.target.value)} placeholder="Re-enter Password" style={{ width: "100%", padding: "10px" }} />

          <button onClick={handleRegister} style={{ marginTop:"20px", width:"100%", padding:"12px", borderRadius:"10px", background:"linear-gradient(to right, #4a62e8ff, #577b98ff)", color:"white", fontWeight:"bold", cursor:"pointer", border:"none" }}>Register</button>

          <p style={{ textAlign: "center", marginTop: "10px" }}>
            Already have an account?{" "}
            <span style={{ color:"blue", cursor:"pointer" }}  onClick={() => navigate("/login")}>Login</span>
          </p>
        </div>
      </div>
    </div>
  );
}
