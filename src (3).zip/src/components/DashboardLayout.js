// src/components/DashboardLayout.js
import React from "react";
import { useNavigate } from "react-router-dom";
import "./dashboardLayout.css";

export default function DashboardLayout({ children, title }) {
  const navigate = useNavigate();

  return (
    <div className="dashboard-layout">
      {/* Header */}
      <header className="dashboard-header">
        <div className="dashboard-left">
          <h1 className="website-name">NeuroFleetX</h1>
          <h2 className="dashboard-title">{title}</h2>
        </div>
<div className="header-right">
  <button
            className="profile-btn"
            onClick={() => navigate("/profile")}
          >
            Profile
          </button>
</div>

      </header>

      {/* Page body */}
      <main className="dashboard-body">{children}</main>
    </div>
  );
}
