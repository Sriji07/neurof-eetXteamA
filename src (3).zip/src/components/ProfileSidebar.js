import React from "react";
import { useNavigate } from "react-router-dom";
import { getUser } from "../utils/authUtils";
import "./ProfileSidebar.css"; // optional styling

const ProfileSidebar = () => {
  const navigate = useNavigate();
  const user = getUser();

  if (!user) return null;

  const handleProfileClick = () => {
    navigate("/profile"); // go to full-page editable profile
  };

  return (
    <div className="sidebar">
      <div className="profile-logo" onClick={handleProfileClick}>
        {user?.name ? user.name.charAt(0).toUpperCase() : "P"}
      </div>

      <div className="sidebar-links">
        <span onClick={() => navigate("/dashboard")}>Dashboard</span>
        {/* Add more sidebar links here */}
      </div>
    </div>
  );
};

export default ProfileSidebar;
