import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import "./profile.css";

export default function Profile() {
  const [user, setUser] = useState({
    name: "",
    email: "",
    role: "",
    dob: "",
    phone: "",
    password: "", // only for input
  });

  const [storedPassword, setStoredPassword] = useState(""); // from localStorage
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [oldPasswordVerified, setOldPasswordVerified] = useState(false);

  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("user"));
    if (savedUser) {
      setUser({
        name: savedUser.name || "",
        email: savedUser.email || "",
        role: savedUser.role || "",
        dob: savedUser.dob || "",
        phone: savedUser.phone || "",
        password: "",
      });
      setStoredPassword(savedUser.password || ""); // store current password
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevUser) => ({ ...prevUser, [name]: value }));
  };

  const handleOldPassword = (e) => {
    setOldPassword(e.target.value);
  };

  const verifyOldPassword = () => {
    if (oldPassword === storedPassword) {
      setOldPasswordVerified(true);
      alert("Old password verified! Enter new password.");
    } else {
      alert("Old password incorrect!");
      setOldPassword("");
    }
  };

  const handleNewPassword = (e) => {
    setNewPassword(e.target.value);
  };

  const saveProfile = () => {
    const updatedUser = {
      name: user.name,
      email: user.email,
      role: user.role,
      dob: user.dob,
      phone: user.phone,
      password: storedPassword, // default
    };

    if (oldPasswordVerified && newPassword.trim() !== "") {
      updatedUser.password = newPassword;
    }

    localStorage.setItem("user", JSON.stringify(updatedUser));
    setStoredPassword(updatedUser.password);
    setOldPassword("");
    setNewPassword("");
    setOldPasswordVerified(false);
    setShowPasswordChange(false);

    alert("Profile updated successfully!");
  };

  return (
    <DashboardLayout dashboardName="Profile">
      <div className="profile-container">
        <h2 className="profile-title">My Profile</h2>
        <div className="profile-card">

          {/* Editable fields */}
          <label>Name</label>
          <input type="text" name="name" value={user.name} onChange={handleChange} />

          <label>Email</label>
          <input type="email" name="email" value={user.email} onChange={handleChange} />

          <label>Role</label>
          <input type="text" name="role" value={user.role} disabled />

          <label>Date of Birth</label>
          <input type="date" name="dob" value={user.dob} onChange={handleChange} />

          <label>Phone Number</label>
          <input type="text" name="phone" value={user.phone} onChange={handleChange} />

          <hr className="divider" />

          {/* Change password section */}
          <h3 onClick={() => setShowPasswordChange(!showPasswordChange)} style={{cursor: "pointer"}}>
            Change Password {showPasswordChange ? "▲" : "▼"}
          </h3>

          {showPasswordChange && (
            <div className="password-change-section">
              {!oldPasswordVerified && (
                <>
                  <label>Enter Old Password</label>
                  <input type="password" value={oldPassword} onChange={handleOldPassword} />
                  <button className="verify-btn" onClick={verifyOldPassword}>Verify Old Password</button>
                </>
              )}

              {oldPasswordVerified && (
                <>
                  <label>Enter New Password</label>
                  <input type="password" value={newPassword} onChange={handleNewPassword} />
                </>
              )}
            </div>
          )}

          {/* Save button */}
          <button className="save-btn" onClick={saveProfile}>
            Save Changes
          </button>
        </div>
      </div>
    </DashboardLayout>
  );
}
