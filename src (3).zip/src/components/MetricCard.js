// src/components/MetricCard.js
import React from "react";
import "./MetricCard.css";

export default function MetricCard({ title, value }) {
  return (
    <div className="metric-card">
      <h3>{title}</h3>
      <p>{value}</p>
    </div>
  );
}
