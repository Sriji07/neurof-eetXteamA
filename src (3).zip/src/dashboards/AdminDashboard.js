import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import MetricCard from "../components/MetricCard";
import "../dashboards/dashboard.css";

export default function AdminDashboard() {
  return (
    <DashboardLayout title="Admin Dashboard">
      <div className="dashboard-main">
        <h2 className="dashboard-welcome">Welcome to Admin Dashboard</h2>

        <div className="metrics-grid">
          <MetricCard title="Total Users" value="1,240" />
          <MetricCard title="Total Fleets" value="58" />
          <MetricCard title="Total Bookings" value="4,890" />
          <MetricCard title="Active Users" value="412" />
          <MetricCard title="Completed Trips" value="10,243" />
          <MetricCard title="Total Revenue" value="₹ 42,75,000" />
        </div>
      </div>
    </DashboardLayout>
  );
}
