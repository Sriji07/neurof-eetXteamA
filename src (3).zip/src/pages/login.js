import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    const data = JSON.parse(localStorage.getItem("userData"));

    if (!data) {
      alert("No registered user found!");
      return;
    }

    if (email === data.email && password === data.password) {
      // Save user to localStorage for dashboards/profile
      localStorage.setItem("user", JSON.stringify(data));

      // Redirect based on role
      const role = data.role.toLowerCase();
      if (role === "admin") navigate("/admin");
      else if (role === "fleet manager") navigate("/fleet");
      else if (role === "driver") navigate("/driver");
      else if (role === "customer") navigate("/customer");
      else navigate("/dashboard"); // fallback
    } else {
      alert("Invalid Login Credentials");
    }
  };

  return (
    <div
      style={{
        minHeight: "80vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backdropFilter: "blur(2px)",
      }}
    >
      <div
        style={{
          width: "420px",
          padding: "35px",
          borderRadius: "25px",
          background: "rgba(255, 255, 255, 0.95)",
          boxShadow: "0 8px 25px rgba(0,0,0,0.25)",
          border: "1px solid rgba(255,255,255,0.3)",
          color: "black",
        }}
      >
        <h1 style={{ textAlign: "center", color: "#2287e5ff" }}>NeuroFleetX</h1>
        <h2 style={{ textAlign: "center", marginBottom: "20px" }}>Login</h2>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: "100%", padding: "12px", borderRadius: "10px", border: "1px solid #0e0101ff" }}
          />

          <label style={{ marginTop: "15px" }}>Password</label>
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: "100%", padding: "12px", borderRadius: "10px", border: "1px solid #100101ff" }}
          />

          <button
            onClick={handleLogin}
            style={{
              marginTop: "22px",
              width: "100%",
              padding: "14px",
              borderRadius: "12px",
              background: "linear-gradient(to right, #5f7eecff, #326ea7ff)",
              color: "white",
              border: "none",
              cursor: "pointer",
              fontWeight: "bold",
              fontSize: "16px",
            }}
          >
            Login
          </button>

          <p style={{ marginTop: "15px", textAlign: "center" }}>
            Don't have an account?{" "}
            <span
              style={{ color: "blue", cursor: "pointer", fontWeight: "bold" }}
              onClick={() => navigate("/register")}
            >
              Register Now
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
