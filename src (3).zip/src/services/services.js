import api from "./apiClient";
import { saveUser } from "../utils/authUtils";

export const loginUser = async (email, password, role) => {
  // Replace with real backend
  const mockUser = {
    name: "John Doe",
    email,
    role,
    token: "mock-jwt-token"
  };

  saveUser(mockUser);
  return true;
};
